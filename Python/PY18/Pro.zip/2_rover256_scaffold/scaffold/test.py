#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 22/05/2018 1:59 PM
# @Author  : Jsen617
# @Site    : 
# @File    : test.py
# @Software: PyCharm

for i in range(1,5):
    print(i)