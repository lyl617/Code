class ListIndexOutOfBoundsException extends IndexOutOfBoundsException {
	public ListIndexOutOfBoundsException(String s) {
		super(s);
	}
}