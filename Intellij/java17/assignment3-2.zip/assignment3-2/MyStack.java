public class MyStack implements StackInterface {
	/* 
	* TODO 1: Implement "MyStack"
	*/

	
	/* 
	* TODO 1: Implement "MyStack"
	*/
}