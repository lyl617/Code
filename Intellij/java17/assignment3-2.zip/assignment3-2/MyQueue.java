public class MyQueue implements QueueInterface {
	/* 
	* TODO 2: Implement "MyQueue"
	*/

	
	/* 
	* TODO 2: Implement "MyQueue"
	*/

} 