public class StackException extends RuntimeException {
	public StackException(String s) {
		super(s);
	}
}