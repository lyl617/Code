
public class MyLinkedList implements ListInterface {

	/* TODO: Write a LinkedList implementation for all the methods specified in ListInterface */ 
	
}
